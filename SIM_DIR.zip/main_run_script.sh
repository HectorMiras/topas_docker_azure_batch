#!/bin/bash

INFILE1="Phase1_SARRP.txt" 
INFILE2="Phase2_Cell.txt" 
INFILE3="Phase3_dnaDamage.txt" 
PYFILE1="sample_positions_in_medium.py"
PYFILE2="sample_positions_in_cell.py"
DELFILE="SARRP_PHSP.phsp"

CURRENTPATH=`pwd`
SEED=`bash -c 'echo $RANDOM'`
sed -i "s/i:Ts\/Seed = .*/i:Ts\/Seed = $SEED/" $CURRENTPATH/$INFILE1
sed -i "s/i:Ts\/Seed = .*/i:Ts\/Seed = $SEED/" $CURRENTPATH/$INFILE2
time /topas/bin/topas $CURRENTPATH/$INFILE1
time /topas/bin/topas $CURRENTPATH/$INFILE2
	
